import React, { useState, useEffect } from 'react';
import { ArrowDownUp, Settings, Search } from 'lucide-react';
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Token } from './types';
import { Jupiter } from '@jup-ag/api';
import { PublicKey } from '@solana/web3.js';
import JSBI from 'jsbi';

function App() {
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const { connected, publicKey, signTransaction } = useWallet();
  const { connection } = useConnection();
  const [tokens, setTokens] = useState<Token[]>([]);
  const [selectedFromToken, setSelectedFromToken] = useState<Token | null>(null);
  const [selectedToToken, setSelectedToToken] = useState<Token | null>(null);
  const [showTokenList, setShowTokenList] = useState(false);
  const [selectingToken, setSelectingToken] = useState<'from' | 'to'>('from');
  const [searchQuery, setSearchQuery] = useState('');
  const [routes, setRoutes] = useState<any[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [swapping, setSwapping] = useState(false);

  // Initialize Jupiter
  const [jupiter, setJupiter] = useState<Jupiter | null>(null);

  useEffect(() => {
    const initJupiter = async () => {
      if (connection) {
        const jupiterInstance = await Jupiter.load({
          connection,
          cluster: 'mainnet-beta',
          wrapUnwrapSOL: true,
        });
        setJupiter(jupiterInstance);
      }
    };
    initJupiter();
  }, [connection]);

  useEffect(() => {
    const fetchTokens = async () => {
      try {
        const response = await fetch('https://token.jup.ag/strict');
        const data = await response.json();
        setTokens(data);
        
        // Set default tokens (SOL and USDC)
        const solToken = data.find((t: Token) => t.symbol === 'SOL');
        const usdcToken = data.find((t: Token) => t.symbol === 'USDC');
        
        if (solToken) setSelectedFromToken(solToken);
        if (usdcToken) setSelectedToToken(usdcToken);
      } catch (error) {
        console.error('Error fetching tokens:', error);
      }
    };

    fetchTokens();
  }, []);

  const filteredTokens = tokens.filter(token => 
    token.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    token.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Fetch routes when tokens or amount changes
  useEffect(() => {
    const fetchRoutes = async () => {
      if (!jupiter || !selectedFromToken || !selectedToToken || !fromAmount || !publicKey) {
        setRoutes([]);
        setSelectedRoute(null);
        return;
      }

      try {
        setLoading(true);
        const amount = JSBI.BigInt(
          Math.round(parseFloat(fromAmount) * Math.pow(10, selectedFromToken.decimals))
        ).toString();

        const routes = await jupiter.computeRoutes({
          inputMint: new PublicKey(selectedFromToken.address),
          outputMint: new PublicKey(selectedToToken.address),
          amount,
          slippageBps: 50, // 0.5%
          forceFetch: true,
        });

        setRoutes(routes.routesInfos);
        if (routes.routesInfos.length > 0) {
          setSelectedRoute(routes.routesInfos[0]);
          setToAmount(
            (parseFloat(routes.routesInfos[0].outAmount) / Math.pow(10, selectedToToken.decimals)).toString()
          );
        }
      } catch (error) {
        console.error('Error fetching routes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRoutes();
  }, [jupiter, selectedFromToken, selectedToToken, fromAmount, publicKey]);

  const handleSwap = async () => {
    if (!jupiter || !selectedRoute || !publicKey || !signTransaction) {
      return;
    }

    try {
      setSwapping(true);
      const { transactions } = await jupiter.exchange({
        routeInfo: selectedRoute,
        userPublicKey: publicKey,
      });

      const { setupTransaction, swapTransaction, cleanupTransaction } = transactions;

      // Sign and send the transactions
      if (setupTransaction) {
        const signedSetup = await signTransaction(setupTransaction);
        const setupTxid = await connection.sendRawTransaction(signedSetup.serialize());
        await connection.confirmTransaction(setupTxid);
      }

      const signedSwap = await signTransaction(swapTransaction);
      const swapTxid = await connection.sendRawTransaction(signedSwap.serialize());
      await connection.confirmTransaction(swapTxid);

      if (cleanupTransaction) {
        const signedCleanup = await signTransaction(cleanupTransaction);
        const cleanupTxid = await connection.sendRawTransaction(signedCleanup.serialize());
        await connection.confirmTransaction(cleanupTxid);
      }

      // Reset form
      setFromAmount('');
      setToAmount('');
      setRoutes([]);
      setSelectedRoute(null);
    } catch (error) {
      console.error('Error during swap:', error);
    } finally {
      setSwapping(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-900 to-red-950 text-white">
      {/* Background strawberries */}
      <div className="fixed inset-0 pointer-events-none opacity-10">
        <img 
          src="https://images.unsplash.com/photo-1587393855524-087f83d95bc9?auto=format&fit=crop&w=2000" 
          alt="Strawberry Pattern" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Navbar */}
      <nav className="relative z-10 px-6 py-4 flex items-center justify-between bg-red-950/50 backdrop-blur-sm">
        <div className="flex items-center gap-2 text-2xl font-bold text-red-100">
          <img 
            src="https://images.unsplash.com/photo-1464965911861-746a04b4bca6?auto=format&fit=crop&w=100" 
            alt="Strawberry Logo" 
            className="w-10 h-10 rounded-full object-cover"
          />
          Strawberry.finance
        </div>
        <div className="flex items-center gap-4">
          <WalletMultiButton className="!bg-red-700 hover:!bg-red-600 transition-colors" />
          <button className="p-2 rounded-lg hover:bg-red-800/50 transition-colors">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="relative z-10 container mx-auto px-4 py-12">
        <div className="max-w-xl mx-auto">
          {/* Swap Card */}
          <div className="bg-red-950/50 backdrop-blur-md rounded-3xl p-6 shadow-xl border border-red-800/30">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">Swap</h2>
              <button className="p-2 hover:bg-red-800/50 rounded-lg transition-colors">
                <Settings className="w-5 h-5" />
              </button>
            </div>

            {/* From Token */}
            <div className="bg-red-900/50 rounded-2xl p-4 mb-2">
              <div className="flex justify-between mb-2">
                <input
                  type="number"
                  placeholder="0.0"
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                  className="bg-transparent text-2xl font-bold outline-none w-full"
                />
                <button 
                  onClick={() => {
                    setSelectingToken('from');
                    setShowTokenList(true);
                  }}
                  className="flex items-center gap-2 px-3 py-1 bg-red-800 rounded-xl hover:bg-red-700 transition-colors"
                >
                  {selectedFromToken ? (
                    <>
                      <img 
                        src={selectedFromToken.logoURI || 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png'} 
                        alt={selectedFromToken.symbol}
                        className="w-6 h-6 rounded-full"
                      />
                      {selectedFromToken.symbol}
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4" />
                      Select Token
                    </>
                  )}
                </button>
              </div>
              <div className="text-red-300">≈ $0.00</div>
            </div>

            {/* Swap Button */}
            <div className="relative h-10 flex justify-center">
              <button 
                onClick={() => {
                  const temp = selectedFromToken;
                  setSelectedFromToken(selectedToToken);
                  setSelectedToToken(temp);
                  const tempAmount = fromAmount;
                  setFromAmount(toAmount);
                  setToAmount(tempAmount);
                }}
                className="absolute top-1/2 -translate-y-1/2 p-2 rounded-xl bg-red-950 border border-red-800 hover:bg-red-900 transition-colors"
              >
                <ArrowDownUp className="w-5 h-5" />
              </button>
            </div>

            {/* To Token */}
            <div className="bg-red-900/50 rounded-2xl p-4 mt-2">
              <div className="flex justify-between mb-2">
                <input
                  type="number"
                  placeholder="0.0"
                  value={toAmount}
                  readOnly
                  className="bg-transparent text-2xl font-bold outline-none w-full"
                />
                <button 
                  onClick={() => {
                    setSelectingToken('to');
                    setShowTokenList(true);
                  }}
                  className="flex items-center gap-2 px-3 py-1 bg-red-800 rounded-xl hover:bg-red-700 transition-colors"
                >
                  {selectedToToken ? (
                    <>
                      <img 
                        src={selectedToToken.logoURI || 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png'} 
                        alt={selectedToToken.symbol}
                        className="w-6 h-6 rounded-full"
                      />
                      {selectedToToken.symbol}
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4" />
                      Select Token
                    </>
                  )}
                </button>
              </div>
              <div className="text-red-300">≈ $0.00</div>
            </div>

            {/* Route Info */}
            {selectedRoute && (
              <div className="mt-4 p-4 bg-red-900/30 rounded-xl">
                <div className="flex justify-between text-sm text-red-300">
                  <span>Rate</span>
                  <span>1 {selectedFromToken?.symbol} ≈ {(parseFloat(selectedRoute.outAmount) / Math.pow(10, selectedToToken?.decimals || 1) / parseFloat(fromAmount)).toFixed(6)} {selectedToToken?.symbol}</span>
                </div>
                <div className="flex justify-between text-sm text-red-300 mt-2">
                  <span>Price Impact</span>
                  <span>{(selectedRoute.priceImpactPct * 100).toFixed(2)}%</span>
                </div>
                <div className="flex justify-between text-sm text-red-300 mt-2">
                  <span>Minimum Received</span>
                  <span>{(parseFloat(selectedRoute.outAmountWithSlippage) / Math.pow(10, selectedToToken?.decimals || 1)).toFixed(6)} {selectedToToken?.symbol}</span>
                </div>
              </div>
            )}

            {/* Swap Button */}
            <button 
              onClick={handleSwap}
              disabled={!connected || !selectedRoute || loading || swapping}
              className={`w-full mt-6 py-4 rounded-xl font-bold transition-colors ${
                connected && selectedRoute && !loading && !swapping
                  ? 'bg-red-600 hover:bg-red-500' 
                  : 'bg-red-800/50 cursor-not-allowed'
              }`}
            >
              {!connected 
                ? 'Connect Wallet to Swap'
                : loading
                ? 'Loading routes...'
                : swapping
                ? 'Swapping...'
                : !selectedRoute
                ? 'Enter an amount'
                : 'Swap'}
            </button>
          </div>

          {/* Stats */}
          <div className="mt-6 bg-red-950/50 backdrop-blur-md rounded-3xl p-6 border border-red-800/30">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-red-300 text-sm">Total Value Locked</div>
                <div className="text-xl font-bold">$0.00</div>
              </div>
              <div>
                <div className="text-red-300 text-sm">24h Volume</div>
                <div className="text-xl font-bold">$0.00</div>
              </div>
              <div>
                <div className="text-red-300 text-sm">Trades</div>
                <div className="text-xl font-bold">0</div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Token List Modal */}
      {showTokenList && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80" onClick={() => setShowTokenList(false)} />
          <div className="relative bg-red-950 rounded-3xl w-full max-w-lg max-h-[80vh] overflow-hidden">
            <div className="p-4 border-b border-red-800">
              <h3 className="text-xl font-bold">Select a token</h3>
              <div className="mt-4 relative">
                <input
                  type="text"
                  placeholder="Search token name or paste address"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-red-900/50 rounded-xl px-4 py-2 pl-10 outline-none"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-red-300" />
              </div>
            </div>
            <div className="overflow-y-auto max-h-[60vh] p-2">
              {filteredTokens.map((token) => (
                <button
                  key={token.address}
                  onClick={() => {
                    if (selectingToken === 'from') {
                      setSelectedFromToken(token);
                    } else {
                      setSelectedToToken(token);
                    }
                    setShowTokenList(false);
                    setSearchQuery('');
                  }}
                  className="w-full flex items-center gap-3 p-2 hover:bg-red-900/50 rounded-xl transition-colors"
                >
                  <img 
                    src={token.logoURI || 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png'} 
                    alt={token.symbol}
                    className="w-8 h-8 rounded-full"
                  />
                  <div className="text-left">
                    <div className="font-bold">{token.symbol}</div>
                    <div className="text-sm text-red-300">{token.name}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;